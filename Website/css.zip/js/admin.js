document.addEventListener("DOMContentLoaded", () => {
    const loginPanel = document.getElementById("login-panel");
    const dashboard = document.getElementById("dashboard");
    const loginForm = document.getElementById("login-form");
    const loginMessage = document.getElementById("login-message");
    const logoutButton = document.getElementById("logout-button");
    const ordersList = document.getElementById("admin-orders");
    const ordersEmpty = document.getElementById("orders-empty");
    const fleetList = document.getElementById("admin-fleet");
    const fleetForm = document.getElementById("fleet-form");
    const fleetMessage = document.getElementById("fleet-message");
    const fleetImageFile = document.getElementById("fleet-image-file");
    const fleetImagePreview = document.getElementById("fleet-image-preview");
    const fleetImagePreviewWrap = document.getElementById("fleet-image-preview-wrap");
    const fleetImagePreviewLabel = document.getElementById("fleet-image-preview-label");
    const fleetCurrentImage = document.getElementById("fleet-current-image");
    const toast = document.getElementById("admin-toast");
    const sessionKey = "autoProManagerDemo";
    const bookingKey = "autoProBookings";
    const statusLabels = {
        pending: "Chờ duyệt",
        active: "Đang thuê",
        completed: "Hoàn thành",
        cancelled: "Đã hủy"
    };
    let toastTimer;
    let previewObjectUrl = "";

    function imageSource(image) {
        const value = String(image || "");
        if (/^data:image\/(?:jpeg|png|webp);base64,[a-z0-9+/]+=*$/i.test(value)) return value;
        if (/^(?:honda|hyundai|mazda3|mercedes|mg5|mitsubishi|vinfast)\.webp$/i.test(value)) {
            return `images/${value}`;
        }
        throw new Error("Ảnh trong danh sách xe không hợp lệ.");
    }

    function showImagePreview(source, label) {
        fleetImagePreview.src = source;
        fleetImagePreviewLabel.textContent = label;
        fleetImagePreviewWrap.hidden = false;
    }

    function releasePreviewUrl() {
        if (!previewObjectUrl) return;
        window.URL.revokeObjectURL(previewObjectUrl);
        previewObjectUrl = "";
    }

    function resizeImage(file) {
        return createImageBitmap(file).then((bitmap) => {
            const maxDimension = 1400;
            const initialScale = Math.min(1, maxDimension / Math.max(bitmap.width, bitmap.height));
            let width = Math.max(1, Math.round(bitmap.width * initialScale));
            let height = Math.max(1, Math.round(bitmap.height * initialScale));
            const canvas = document.createElement("canvas");
            const context = canvas.getContext("2d");
            if (!context) {
                bitmap.close();
                throw new Error("Không thể xử lý ảnh này trên trình duyệt.");
            }

            const maxBytes = 400 * 1024;
            let attempt = 0;
            function encode() {
                canvas.width = width;
                canvas.height = height;
                context.clearRect(0, 0, width, height);
                context.drawImage(bitmap, 0, 0, width, height);
                return new Promise((resolve, reject) => {
                    canvas.toBlob((blob) => {
                        if (!blob) {
                            reject(new Error("Không thể nén ảnh đã chọn."));
                            return;
                        }
                        if (blob.size <= maxBytes) {
                            const reader = new FileReader();
                            reader.onload = () => resolve(reader.result);
                            reader.onerror = () => reject(new Error("Không thể đọc ảnh đã xử lý."));
                            reader.readAsDataURL(blob);
                            return;
                        }
                        attempt += 1;
                        if (attempt >= 5) {
                            reject(new Error("Ảnh vẫn quá lớn sau khi nén. Vui lòng chọn ảnh nhỏ hơn."));
                            return;
                        }
                        width = Math.max(320, Math.round(width * 0.82));
                        height = Math.max(320, Math.round(height * 0.82));
                        encode().then(resolve, reject);
                    }, "image/webp", Math.max(0.55, 0.84 - attempt * 0.07));
                });
            }

            return encode().finally(() => bitmap.close());
        });
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, (character) => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        })[character]);
    }

    function showToast(message) {
        toast.textContent = message;
        toast.classList.add("show");
        window.clearTimeout(toastTimer);
        toastTimer = window.setTimeout(() => toast.classList.remove("show"), 3200);
    }

    function readBookings() {
        const stored = window.localStorage.getItem(bookingKey);
        if (stored === null) return [];
        const bookings = JSON.parse(stored);
        if (!Array.isArray(bookings)) {
            throw new Error("Dữ liệu đơn đặt xe không hợp lệ.");
        }
        return bookings;
    }

    function updateOverview(bookings, fleet) {
        document.getElementById("stat-orders").textContent = String(bookings.length);
        document.getElementById("stat-pending").textContent = String(bookings.filter((booking) => booking.status === "pending").length);
        document.getElementById("stat-active").textContent = String(bookings.filter((booking) => booking.status === "active").length);
        document.getElementById("stat-fleet").textContent = String(fleet.length);
    }

    function renderOrders(bookings) {
        const query = document.getElementById("order-search").value.trim().toLocaleLowerCase("vi");
        const visibleBookings = bookings.filter((booking) => [
            booking.id,
            booking.fullname,
            booking.email,
            booking.carType
        ].some((value) => String(value || "").toLocaleLowerCase("vi").includes(query)));

        ordersList.innerHTML = visibleBookings.map((booking) => {
            const id = escapeHTML(booking.id);
            const status = Object.hasOwn(statusLabels, booking.status) ? booking.status : "pending";
            return `<article class="admin-order">
                <div>
                    <span class="order-code">${id}</span>
                    <h3>${escapeHTML(booking.carType || "Chưa chọn xe")}</h3>
                    <p>Khách hàng: ${escapeHTML(booking.fullname || "Chưa cập nhật")} · ${escapeHTML(booking.phone || booking.email || "Chưa có liên hệ")}</p>
                    <p>Thời gian: ${escapeHTML(booking.pickupDate || "—")} đến ${escapeHTML(booking.returnDate || "—")}</p>
                </div>
                <div class="order-controls">
                    <label class="sr-only" for="status-${escapeHTML(id)}">Trạng thái đơn ${id}</label>
                    <select class="order-status" id="status-${escapeHTML(id)}" data-order-id="${id}">
                        ${Object.entries(statusLabels).map(([value, label]) => `<option value="${value}"${value === status ? " selected" : ""}>${label}</option>`).join("")}
                    </select>
                </div>
            </article>`;
        }).join("");

        ordersEmpty.hidden = visibleBookings.length > 0;
    }

    function renderFleet(fleet) {
        fleetList.innerHTML = fleet.map((car) => `<article class="admin-car" data-car-id="${escapeHTML(car.id)}">
            <img src="${escapeHTML(imageSource(car.image))}" alt="${escapeHTML(car.name)}">
            <div>
                <h3>${escapeHTML(car.name)}</h3>
                <p>${escapeHTML(car.brand)} · ${escapeHTML(car.category)} · ${Number(car.seats)} chỗ</p>
                <p>${Number(car.price).toLocaleString("vi-VN")}đ / ngày${car.featured ? " · Nổi bật" : ""}</p>
            </div>
            <div class="admin-car-actions">
                <button class="button button-outline" type="button" data-action="edit" data-car-id="${escapeHTML(car.id)}">Sửa</button>
                <button class="button button-danger" type="button" data-action="delete" data-car-id="${escapeHTML(car.id)}">Xóa</button>
            </div>
        </article>`).join("");
    }

    function refreshDashboard() {
        const bookings = readBookings();
        const fleet = window.AutoProFleet.load();
        updateOverview(bookings, fleet);
        renderOrders(bookings);
        renderFleet(fleet);
    }

    function showDashboard() {
        loginPanel.hidden = true;
        dashboard.hidden = false;
        logoutButton.hidden = false;
        refreshDashboard();
    }

    function resetFleetForm() {
        releasePreviewUrl();
        fleetForm.reset();
        document.getElementById("fleet-id").value = "";
        fleetCurrentImage.value = "";
        fleetImageFile.value = "";
        document.getElementById("fleet-seats").value = "5";
        document.getElementById("fleet-transmission").value = "Tự động";
        document.getElementById("fleet-form-title").textContent = "Thêm xe mới";
        document.getElementById("fleet-save").textContent = "Thêm xe vào dàn";
        document.getElementById("fleet-cancel").hidden = true;
        fleetMessage.textContent = "";
        fleetImagePreviewWrap.hidden = true;
    }

    function reportError(message) {
        loginMessage.textContent = message;
        fleetMessage.textContent = message;
        console.error(message);
    }

    if (loginForm) {
        try {
            if (window.sessionStorage.getItem(sessionKey) === "signed-in") {
                showDashboard();
            }
        } catch (error) {
            reportError("Không thể truy cập phiên đăng nhập của trình duyệt. Vui lòng mở trang bằng máy chủ web cục bộ.");
        }

        loginForm.addEventListener("submit", (event) => {
            event.preventDefault();
            loginMessage.textContent = "";
            document.getElementById("username-error").textContent = "";
            document.getElementById("password-error").textContent = "";

            const username = document.getElementById("admin-username").value.trim();
            const password = document.getElementById("admin-password").value;
            let valid = true;

            if (!username) {
                document.getElementById("username-error").textContent = "Vui lòng nhập tài khoản.";
                valid = false;
            }
            if (!password) {
                document.getElementById("password-error").textContent = "Vui lòng nhập mật khẩu.";
                valid = false;
            }
            if (!valid) return;

            if (username !== "admin" || password !== "AutoPro2026!") {
                loginMessage.textContent = "Tài khoản hoặc mật khẩu chưa đúng. Hãy dùng thông tin demo hiển thị phía trên.";
                return;
            }

            try {
                window.sessionStorage.setItem(sessionKey, "signed-in");
                showDashboard();
            } catch (error) {
                reportError("Không thể tạo phiên đăng nhập demo trong trình duyệt.");
            }
        });
    }

    logoutButton.addEventListener("click", () => {
        try {
            window.sessionStorage.removeItem(sessionKey);
            dashboard.hidden = true;
            loginPanel.hidden = false;
            logoutButton.hidden = true;
            loginForm.reset();
            loginMessage.textContent = "";
        } catch (error) {
            reportError("Không thể kết thúc phiên đăng nhập demo.");
        }
    });

    document.getElementById("order-search").addEventListener("input", () => {
        try {
            renderOrders(readBookings());
        } catch (error) {
            reportError("Không thể tìm đơn hàng. Dữ liệu lưu trữ có thể không hợp lệ.");
        }
    });

    ordersList.addEventListener("change", (event) => {
        const select = event.target.closest(".order-status");
        if (!select) return;

        try {
            const bookings = readBookings();
            const booking = bookings.find((item) => item.id === select.dataset.orderId);
            if (!booking) {
                showToast("Không tìm thấy đơn hàng cần cập nhật.");
                return;
            }
            booking.status = select.value;
            window.localStorage.setItem(bookingKey, JSON.stringify(bookings));
            refreshDashboard();
            showToast(`Đã cập nhật trạng thái đơn ${booking.id}.`);
        } catch (error) {
            reportError("Không thể lưu trạng thái đơn. Vui lòng kiểm tra quyền lưu trữ của trình duyệt.");
        }
    });

    fleetList.addEventListener("click", (event) => {
        const button = event.target.closest("button[data-action]");
        if (!button) return;

        try {
            const fleet = window.AutoProFleet.load();
            const car = fleet.find((item) => item.id === button.dataset.carId);
            if (!car) {
                showToast("Không tìm thấy xe cần thao tác.");
                return;
            }

            if (button.dataset.action === "edit") {
                document.getElementById("fleet-id").value = car.id;
                document.getElementById("fleet-brand").value = car.brand;
                document.getElementById("fleet-name").value = car.name;
                document.getElementById("fleet-category").value = car.category;
                document.getElementById("fleet-seats").value = String(car.seats);
                document.getElementById("fleet-transmission").value = car.transmission;
                document.getElementById("fleet-price").value = String(car.price);
                document.getElementById("fleet-tag").value = car.tag || "";
                fleetCurrentImage.value = car.image;
                fleetImageFile.value = "";
                releasePreviewUrl();
                showImagePreview(imageSource(car.image), "Ảnh hiện tại · Chọn tệp mới để thay đổi");
                document.getElementById("fleet-featured").checked = Boolean(car.featured);
                document.getElementById("fleet-form-title").textContent = "Chỉnh sửa thông tin xe";
                document.getElementById("fleet-save").textContent = "Lưu thay đổi";
                document.getElementById("fleet-cancel").hidden = false;
                fleetForm.scrollIntoView({ behavior: "smooth", block: "start" });
                return;
            }

            if (window.confirm(`Xóa ${car.name} khỏi dàn xe?`)) {
                window.AutoProFleet.save(fleet.filter((item) => item.id !== car.id));
                refreshDashboard();
                showToast(`Đã xóa ${car.name} khỏi dàn xe.`);
            }
        } catch (error) {
            reportError("Không thể cập nhật dàn xe. Vui lòng kiểm tra dữ liệu lưu trữ.");
        }
    });

    fleetImageFile.addEventListener("change", () => {
        const file = fleetImageFile.files[0];
        fleetMessage.textContent = "";
        if (!file) {
            releasePreviewUrl();
            if (fleetCurrentImage.value) {
                showImagePreview(imageSource(fleetCurrentImage.value), "Ảnh hiện tại · Chọn tệp mới để thay đổi");
            } else {
                fleetImagePreviewWrap.hidden = true;
            }
            return;
        }
        if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
            fleetImageFile.value = "";
            fleetMessage.textContent = "Vui lòng chọn ảnh JPG, PNG hoặc WebP.";
            return;
        }
        if (file.size > 8 * 1024 * 1024) {
            fleetImageFile.value = "";
            fleetMessage.textContent = "Kích thước ảnh gốc tối đa là 8 MB.";
            return;
        }
        releasePreviewUrl();
        previewObjectUrl = window.URL.createObjectURL(file);
        showImagePreview(previewObjectUrl, `Ảnh mới: ${file.name}`);
    });

    fleetForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        fleetMessage.textContent = "";
        if (!fleetForm.reportValidity()) return;

        const editingId = document.getElementById("fleet-id").value;
        const selectedFile = fleetImageFile.files[0];
        if (!selectedFile && !fleetCurrentImage.value) {
            fleetMessage.textContent = "Vui lòng chọn ảnh xe từ máy tính.";
            fleetImageFile.focus();
            return;
        }
        const selectedImage = selectedFile
            ? await resizeImage(selectedFile).catch((error) => {
                fleetMessage.textContent = error.message || "Không thể xử lý ảnh đã chọn.";
                return null;
            })
            : fleetCurrentImage.value;
        if (!selectedImage) return;
        const car = {
            id: editingId || `${document.getElementById("fleet-brand").value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${Date.now()}`,
            brand: document.getElementById("fleet-brand").value.trim(),
            name: document.getElementById("fleet-name").value.trim(),
            category: document.getElementById("fleet-category").value.trim(),
            seats: Number(document.getElementById("fleet-seats").value),
            transmission: document.getElementById("fleet-transmission").value.trim(),
            price: Number(document.getElementById("fleet-price").value),
            tag: document.getElementById("fleet-tag").value.trim() || document.getElementById("fleet-category").value.trim(),
            image: selectedImage,
            featured: document.getElementById("fleet-featured").checked
        };

        try {
            const fleet = window.AutoProFleet.load();
            const existingIndex = fleet.findIndex((item) => item.id === editingId);
            if (!editingId && fleet.some((item) => item.name.toLocaleLowerCase("vi") === car.name.toLocaleLowerCase("vi"))) {
                fleetMessage.textContent = "Tên xe này đã có trong dàn. Vui lòng chọn tên khác.";
                return;
            }
            if (editingId && existingIndex === -1) {
                fleetMessage.textContent = "Không tìm thấy xe cần cập nhật. Hãy tải lại trang.";
                return;
            }

            if (editingId) {
                fleet[existingIndex] = car;
            } else {
                fleet.push(car);
            }
            window.AutoProFleet.save(fleet);
            resetFleetForm();
            refreshDashboard();
            showToast(editingId ? "Đã lưu thay đổi thông tin xe." : "Đã thêm xe vào dàn.");
        } catch (error) {
            reportError("Không thể lưu dàn xe. Vui lòng kiểm tra quyền lưu trữ của trình duyệt.");
        }
    });

    document.getElementById("fleet-cancel").addEventListener("click", resetFleetForm);

    window.addEventListener("storage", (event) => {
        if (event.key === bookingKey || event.key === window.AutoProFleet.storageKey) {
            try {
                refreshDashboard();
            } catch (error) {
                reportError("Không thể đồng bộ dữ liệu cửa hàng từ tab khác.");
            }
        }
    });
});
