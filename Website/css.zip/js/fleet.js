(() => {
    const storageKey = "autoProFleet";
    const defaultFleet = [
        { id: "honda-civic", brand: "Honda", name: "Honda Civic", category: "Sedan", seats: 5, transmission: "Tự động", price: 1200000, tag: "Phổ biến", image: "honda.webp", featured: true },
        { id: "hyundai-santa-fe", brand: "Hyundai", name: "Hyundai Santa Fe", category: "SUV", seats: 7, transmission: "Tự động", price: 1800000, tag: "SUV rộng rãi", image: "hyundai.webp", featured: true },
        { id: "mazda-3", brand: "Mazda", name: "Mazda 3", category: "Sedan", seats: 5, transmission: "Tự động", price: 1100000, tag: "Thể thao", image: "mazda3.webp", featured: false },
        { id: "mercedes-c-class", brand: "Mercedes-Benz", name: "Mercedes-Benz C-Class", category: "Sedan", seats: 5, transmission: "Tự động", price: 2800000, tag: "Cao cấp", image: "mercedes.webp", featured: true },
        { id: "mg5", brand: "MG", name: "MG5", category: "Sedan", seats: 5, transmission: "Tự động", price: 850000, tag: "Giá tốt", image: "mg5.webp", featured: false },
        { id: "mitsubishi-xpander", brand: "Mitsubishi", name: "Mitsubishi Xpander", category: "MPV", seats: 7, transmission: "Tự động", price: 950000, tag: "Gia đình", image: "mitsubishi.webp", featured: false },
        { id: "vinfast-vf-8", brand: "VinFast", name: "VinFast VF 8", category: "SUV điện", seats: 5, transmission: "Điện", price: 1600000, tag: "Xe điện", image: "vinfast.webp", featured: false }
    ];

    function load() {
        const stored = window.localStorage.getItem(storageKey);
        if (stored === null) {
            save(defaultFleet);
            return defaultFleet.map((car) => ({ ...car }));
        }

        const fleet = JSON.parse(stored);
        if (!Array.isArray(fleet)) {
            throw new Error("Dữ liệu danh sách xe không hợp lệ.");
        }
        return fleet;
    }

    function save(fleet) {
        window.localStorage.setItem(storageKey, JSON.stringify(fleet));
    }

    function escapeHTML(value) {
        return String(value).replace(/[&<>"']/g, (character) => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        })[character]);
    }

    function imageSource(image) {
        const value = String(image || "");
        if (/^data:image\/(?:jpeg|png|webp);base64,[a-z0-9+/]+=*$/i.test(value)) return value;
        if (/^(?:honda|hyundai|mazda3|mercedes|mg5|mitsubishi|vinfast)\.webp$/i.test(value)) {
            return `images/${value}`;
        }
        throw new Error("Ảnh trong danh sách xe không hợp lệ.");
    }

    function renderCard(car) {
        const name = escapeHTML(car.name);
        const brand = escapeHTML(car.brand);
        const category = escapeHTML(car.category);
        const tag = escapeHTML(car.tag || category);
        const image = escapeHTML(imageSource(car.image));
        const transmission = escapeHTML(car.transmission);
        const price = Number(car.price).toLocaleString("vi-VN");
        const href = `booking.html?car=${encodeURIComponent(car.name)}`;

        return `<article class="car-card" data-brand="${brand}" data-name="${name}" data-price="${Number(car.price)}">
            <div class="car-image"><img src="${image}" alt="${name}" loading="lazy"><span class="car-tag">${tag}</span></div>
            <div class="car-body">
                <div class="car-make"><span>${brand.toUpperCase()} · ${category.toUpperCase()}</span></div>
                <h3>${name}</h3>
                <div class="car-specs"><span>♙ ${Number(car.seats)} chỗ</span><span>⚙ ${transmission}</span></div>
                <div class="car-bottom"><div class="price">${price}đ <small>/ ngày</small></div><a href="${href}" class="button">Thuê ngay</a></div>
            </div>
        </article>`;
    }

    function renderFilters(fleet) {
        const filterGroup = document.getElementById("brand-filters");
        if (!filterGroup) return;

        const brands = [...new Set(fleet.map((car) => car.brand))];
        filterGroup.innerHTML = [
            '<button class="filter selected" type="button" data-filter="all">Tất cả hãng</button>',
            ...brands.map((brand) => `<button class="filter" type="button" data-filter="${escapeHTML(brand)}">${escapeHTML(brand)}</button>`)
        ].join("");
    }

    function renderFleet() {
        const fleet = load();
        const productGrid = document.getElementById("car-grid");
        if (productGrid) {
            productGrid.innerHTML = fleet.map(renderCard).join("");
            renderFilters(fleet);
            const emptyState = document.getElementById("empty-state");
            if (emptyState) emptyState.classList.toggle("show", fleet.length === 0);
        }

        const featuredGrid = document.getElementById("featured-cars");
        if (featuredGrid) {
            const featured = fleet.filter((car) => car.featured).slice(0, 3);
            const visibleCars = featured.length ? featured : fleet.slice(0, 3);
            featuredGrid.innerHTML = visibleCars.map(renderCard).join("");
        }

        const carType = document.getElementById("car-type");
        if (carType) {
            const selectedValue = new URLSearchParams(window.location.search).get("car");
            carType.innerHTML = '<option value="">-- Chọn dòng xe --</option>' +
                fleet.map((car) => {
                    const name = escapeHTML(car.name);
                    return `<option value="${name}"${car.name === selectedValue ? " selected" : ""}>${name} (${escapeHTML(car.category)})</option>`;
                }).join("");
        }
    }

    window.AutoProFleet = { storageKey, defaultFleet, load, save, renderFleet };

    try {
        renderFleet();
    } catch (error) {
        console.error("Không thể tải danh sách xe:", error);
        const grid = document.getElementById("car-grid") || document.getElementById("featured-cars");
        if (grid) {
            grid.innerHTML = '<p class="empty-state show">Không thể tải danh sách xe. Vui lòng kiểm tra dữ liệu lưu trữ.</p>';
        }
    }
})();
